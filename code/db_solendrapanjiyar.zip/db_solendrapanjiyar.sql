-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2014 at 01:43 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `solendrapanjiyar`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_events`
--

CREATE TABLE IF NOT EXISTS `tbl_events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `details` text NOT NULL,
  `venue` varchar(150) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(80) NOT NULL,
  `post_date` datetime NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `tbl_events`
--

INSERT INTO `tbl_events` (`event_id`, `user_id`, `title`, `details`, `venue`, `event_date`, `event_time`, `post_date`) VALUES
(20, 65, 'Saraswati Puja', 'Softarica College is organising this puja ', 'Diliibazar', '2014-03-27', '01:00:00 AM', '2014-01-31 12:52:15'),
(34, 129, 'Sanitaion ', ' Bagmati river sanitaion program organised by the Kathmandu Youth Club.Every interested person are welcome to join the programm', 'Gaushala', '2014-02-28', '08:00:00 AM', '2014-01-29 11:48:10'),
(35, 129, 'Loktantra', 'Celebration of loktandra achievement and speech by the PM and other political leaders ', 'Tudikhel', '2014-03-27', '10:00:00 PM', '2014-01-29 11:50:57'),
(37, 15, 'Jatra', ' Indra Jatra is going to be organised by the SS Youth Club', 'Hanumandhoka', '2014-03-20', '04:00:00 PM', '2014-01-29 12:01:26'),
(39, 130, 'Fresher Party', ' Softwarica College is going to organize fresher party for Batch 10', 'Annapurna Hotel', '2014-03-31', '01:00:00 PM', '2014-01-31 12:54:22'),
(40, 130, 'Blood Donation', ' Youth Club of Softwarica is organizing blood donation Program', 'Dillibazar,Kathmandu', '2014-03-22', '09:00:00 AM', '2014-01-31 12:56:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_participations`
--

CREATE TABLE IF NOT EXISTS `tbl_participations` (
  `participation_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('Going','NotGoing','Thinking') NOT NULL,
  PRIMARY KEY (`participation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `tbl_participations`
--

INSERT INTO `tbl_participations` (`participation_id`, `event_id`, `user_id`, `type`) VALUES
(20, 15, 65, 'Going'),
(21, 20, 65, 'Going'),
(22, 21, 15, 'Going'),
(26, 20, 15, 'Going'),
(27, 22, 15, 'Thinking'),
(28, 24, 15, 'Thinking'),
(29, 15, 15, 'NotGoing'),
(31, 28, 65, 'NotGoing'),
(34, 32, 15, 'Going'),
(35, 31, 15, 'NotGoing'),
(36, 32, 65, 'Going'),
(37, 34, 15, 'Thinking'),
(38, 35, 15, 'NotGoing'),
(40, 37, 15, 'Thinking'),
(42, 39, 130, 'Going');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `un` varchar(25) NOT NULL,
  `email` varchar(80) NOT NULL,
  `pwd` varchar(25) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `status` enum('new','active','block') NOT NULL,
  `last_login` datetime NOT NULL,
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=131 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `fname`, `lname`, `un`, `email`, `pwd`, `gender`, `status`, `last_login`, `reg_date`) VALUES
(15, 'solendra', 'panjiyar', 'solen', 'psolendra@gmail.com', 'admin123', 'male', 'active', '2014-01-31 21:06:40', '2014-01-07 08:55:59'),
(65, 'admin', 'admin', 'admin', 'admin@mail.com', 'admin', 'male', 'active', '2014-01-31 12:51:31', '2014-01-17 06:56:45'),
(129, 'Jitendra', 'Maharjan', 'jiten', 'jiten@softwarica.edu.np', 'admin', 'male', 'active', '2014-01-31 20:36:24', '2014-01-29 03:24:15'),
(130, 'niman', 'maharjan', 'niman', 'niman@softwarica.edu.np', 'admin', 'male', 'active', '2014-01-31 12:52:41', '2014-01-29 08:25:27');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
